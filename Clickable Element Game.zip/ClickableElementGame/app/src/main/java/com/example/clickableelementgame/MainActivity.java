package com.example.clickableelementgame;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.util.DisplayMetrics;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView scoreTextView;
    private int score = 0;
    private int level = 1;
    private Handler handler = new Handler();
    private ClickableElement clickableElement;
    private final int TARGET_SCORE = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Utwórz główny układ ekranu jako RelativeLayout
        RelativeLayout layout = new RelativeLayout(this);
        layout.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT));

        // Utwórz TextView do wyświetlania wyniku
        scoreTextView = new TextView(this);
        RelativeLayout.LayoutParams scoreParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        scoreParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        scoreParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
        scoreTextView.setLayoutParams(scoreParams);
        scoreTextView.setText("Score: 0");
        scoreTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        layout.addView(scoreTextView);

        // Utwórz klikalny element
        clickableElement = new ClickableElement(this);
        RelativeLayout.LayoutParams elementParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        elementParams.addRule(RelativeLayout.CENTER_IN_PARENT);
        clickableElement.setLayoutParams(elementParams);
        layout.addView(clickableElement);

        setContentView(layout);

        clickableElement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score++;
                scoreTextView.setText("Score: " + score);
                clickableElement.setVisibility(View.GONE);
                if (score % TARGET_SCORE == 0) { // Awansuj do kolejnego poziomu po osiągnięciu docelowej liczby punktów
                    level++;
                    scoreTextView.setText("Score: " + score + "\nLevel: " + level);
                }
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        generateNewElement(layout);
                    }
                }, getDelayForLevel(level)); // Generate new element after delay based on level
            }
        });

        generateNewElement(layout);
    }

    private void generateNewElement(RelativeLayout layout) {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;

        Random random = new Random();

        int x = random.nextInt(width - clickableElement.getWidth());
        int y = random.nextInt(height - clickableElement.getHeight());

        clickableElement.setX(x);
        clickableElement.setY(y);
        clickableElement.setVisibility(View.VISIBLE);

        // Ustaw kolejne wywołanie dla klikalnego elementu
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                clickableElement.setVisibility(View.GONE);
                generateNewElement(layout);
            }
        }, getDelayForLevel(level));
    }

    private long getDelayForLevel(int level) {
        // Delay is initially 3000 milliseconds and decreases by 200 milliseconds per level
        return Math.max(1000, 3000 - (200 * (level - 1)));
    }
}


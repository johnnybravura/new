package com.example.clickableelementgame;

import android.content.Context;
import androidx.appcompat.widget.AppCompatImageView;

public class ClickableElement extends AppCompatImageView {

    public ClickableElement(Context context) {
        super(context);
        init();
    }

    private void init() {
        setImageResource(R.drawable.element);
        setClickable(true);
    }
}

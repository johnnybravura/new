package com.example.platgame;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

public class GameActivity extends Activity {

    private GameView gameView;
    private Button jumpButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Inicjalizacja widoku gry
        gameView = new GameView(this);
        FrameLayout gameFrameLayout = findViewById(R.id.game_frame_layout);
        gameFrameLayout.addView(gameView);

        // Inicjalizacja przycisku do skoku
        jumpButton = findViewById(R.id.jump_button);
        jumpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameView.jump(); // Wywołanie metody skoku w widoku gry
            }
        });
    }
}

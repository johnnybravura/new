package com.example.platgame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameView extends View {

    private static final int PLAYER_SIZE = 100;
    private static final int GRAVITY = 5;
    private static final int OBSTACLE_WIDTH = 150;
    private static final int OBSTACLE_HEIGHT = 50;
    private static final int OBSTACLE_GAP = 300;
    private static final int OBSTACLE_SPEED = 10;

    private int playerX;
    private int playerY;
    private int playerSize;
    private int gravity;
    private int score;

    private List<Obstacle> obstacles;
    private Paint playerPaint;
    private Paint obstaclePaint;
    private Paint scorePaint;
    private Handler handler;

    private boolean isGameOver;

    public GameView(Context context) {
        super(context);
        init();
    }

    public GameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        playerSize = PLAYER_SIZE;
        gravity = GRAVITY;
        playerPaint = new Paint();
        playerPaint.setColor(Color.BLUE);
        obstaclePaint = new Paint();
        obstaclePaint.setColor(Color.RED);
        scorePaint = new Paint();
        scorePaint.setColor(Color.WHITE);
        scorePaint.setTextSize(80);
        obstacles = new ArrayList<>();
        handler = new Handler();
        startGame();
    }

    private void startGame() {
        playerX = getWidth() / 2 - playerSize / 2;
        playerY = getHeight() / 2 - playerSize / 2;
        obstacles.clear();
        score = 0;
        isGameOver = false;
        handler.postDelayed(gameLoop, 20);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Rysowanie gracza
        canvas.drawRect(playerX, playerY, playerX + playerSize, playerY + playerSize, playerPaint);

        // Rysowanie przeszkód
        for (Obstacle obstacle : obstacles) {
            canvas.drawRect(obstacle.getX(), 0, obstacle.getX() + OBSTACLE_WIDTH, obstacle.getHeight(), obstaclePaint);
            canvas.drawRect(obstacle.getX(), obstacle.getHeight() + OBSTACLE_GAP, obstacle.getX() + OBSTACLE_WIDTH, getHeight(), obstaclePaint);
        }

        // Rysowanie punktacji
        canvas.drawText("Score: " + score, 50, 100, scorePaint);

        // Rysowanie komunikatu o końcu gry
        if (isGameOver) {
            Paint gameOverPaint = new Paint();
            gameOverPaint.setColor(Color.RED);
            gameOverPaint.setTextSize(100);
            canvas.drawText("Game Over", getWidth() / 2 - 250, getHeight() / 2, gameOverPaint);
        }
    }

    private Runnable gameLoop = new Runnable() {
        @Override
        public void run() {
            updateGame();
            invalidate();
            handler.postDelayed(this, 20);
        }
    };

    private void updateGame() {
        if (isGameOver) return;

        // Aktualizacja pozycji gracza
        playerY += gravity;

        // Sprawdzenie kolizji z przeszkodami
        for (Obstacle obstacle : obstacles) {
            if (obstacle.collides(playerX, playerY, playerSize)) {
                // Gra kończy się, gdy wystąpi kolizja
                isGameOver = true;
                handler.removeCallbacks(gameLoop);
                break;
            }
        }

        // Usunięcie przeszkód, które opuściły obszar widoku
        if (!obstacles.isEmpty() && obstacles.get(0).getX() + OBSTACLE_WIDTH < 0) {
            obstacles.remove(0);
            score++; // Zwiększenie punktacji za każdą przeszkodę, która została przebyta
        }

        // Dodanie nowych przeszkód w losowych odstępach
        if (obstacles.isEmpty() || getWidth() - obstacles.get(obstacles.size() - 1).getX() >= 300) {
            obstacles.add(new Obstacle(getWidth(), getHeight()));
        }
    }

    public void jump() {
        // Logika skoku
        playerY -= 100;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN && !isGameOver) {
            jump(); // Wywołanie skoku po dotknięciu ekranu
            return true;
        }
        return super.onTouchEvent(event);
    }

    // Klasa reprezentująca przeszkodę
    // Klasa reprezentująca przeszkodę
    private class Obstacle {
        private int x;
        private int height;

        public Obstacle(int screenWidth, int screenHeight) {
            Random random = new Random();
            x = screenWidth;
            height = random.nextInt(screenHeight - 2 * OBSTACLE_GAP) + OBSTACLE_GAP;
        }

        public int getX() {
            return x;
        }

        public int getHeight() {
            return height;
        }

        public boolean collides(int playerX, int playerY, int playerSize) {
            return playerX + playerSize >= x && playerX <= x + OBSTACLE_WIDTH && (playerY <= height || playerY + playerSize >= height + OBSTACLE_GAP);
        }
    }
}